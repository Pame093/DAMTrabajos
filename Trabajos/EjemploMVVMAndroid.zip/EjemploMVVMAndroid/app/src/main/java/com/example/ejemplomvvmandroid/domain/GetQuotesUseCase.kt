package com.example.ejemplomvvmandroid.domain

import com.example.ejemplomvvmandroid.data.QuoteRepository
import com.example.ejemplomvvmandroid.data.model.QuoteModel

class GetQuotesUseCase {

    private val repository = QuoteRepository()

    suspend operator fun invoke(): List<QuoteModel>? = repository.getAllQuotes()

}