package com.example.ejemplomvvmandroid.data.model

class QuoteProvider {
    companion object {
        var quotes: List<QuoteModel> = emptyList()
    }
}