package com.example.ejemplomvvmandroid.data

import com.example.ejemplomvvmandroid.data.model.QuoteModel
import com.example.ejemplomvvmandroid.data.model.QuoteProvider
import com.example.ejemplomvvmandroid.data.network.QuoteService

class QuoteRepository {

    private val api = QuoteService()

    suspend fun getAllQuotes(): List<QuoteModel> {
        val response = api.getQuotes()
        QuoteProvider.quotes = response
        return response
    }
}